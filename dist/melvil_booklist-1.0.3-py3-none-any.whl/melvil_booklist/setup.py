from setuptools import setup

setup(
    name='booklist-melvil',
    version='1.0.3',
    url='https://pypi.org/project/melvil-booklist/',
    author='Collisteru',
    author_email='collisteru@gmail.com',
    description='The command line book management tool.',
    long_description='The command line book management tool.',
)