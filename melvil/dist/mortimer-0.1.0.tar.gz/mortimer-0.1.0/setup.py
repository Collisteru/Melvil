# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mortimer']

package_data = \
{'': ['*']}

install_requires = \
['inquirer>=2.10.0,<3.0.0',
 'python-Levenshtein>=0.12.2,<0.13.0',
 'thefuzz>=0.19.0,<0.20.0',
 'typer[all]>=0.6.1,<0.7.0']

entry_points = \
{'console_scripts': ['helper = mortimer.helper:*',
                     'mortimer = mortimer.main:app']}

setup_kwargs = {
    'name': 'mortimer',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Mortimer\n\nThe command line book management tool.',
    'author': 'Sean',
    'author_email': 'sean14520@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
